﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace zimesanas_paligs
{
    public partial class Form2 : Form
    {
       
            Random rand = new Random();
        
        public Form2()
        {
            InitializeComponent();
        }

        private void panelviens_Paint(object sender, PaintEventArgs e)
        {

        }

      

        private void butizvele1_Click_1(object sender, EventArgs e)
        {
            
            Color[] colors = new Color[8]
            {
    Color.DarkRed,
    Color.DarkOrange,
    Color.Gold,
    Color.ForestGreen,
    Color.SteelBlue,
    Color.DarkMagenta,
    Color.Pink,
    Color.Black
            };
            panelviens.BackColor = colors[rand.Next(8)];
        }

        private void butizvele2_Click(object sender, EventArgs e)
        {
          
            Color[] colors = new Color[8]
            {
    Color.DarkRed,
    Color.DarkOrange,
    Color.Gold,
    Color.ForestGreen,
    Color.SteelBlue,
    Color.DarkMagenta,
    Color.Pink,
    Color.Black
            };
            int x = rand.Next(8);
            int y;
            do
            {
                y = rand.Next(8);
            }
            while (y == x);
            paneldivi.BackColor = colors[x];
            paneltris.BackColor = colors[y];

        }

        private void butizvele3_Click(object sender, EventArgs e)
        {
            Color[] colors = new Color[8]
          {
    Color.DarkRed,
    Color.DarkOrange,
    Color.Gold,
    Color.ForestGreen,
    Color.SteelBlue,
    Color.DarkMagenta,
    Color.Pink,
    Color.Black
            };
            int x = rand.Next(8);
            int y,z;
           
            do
            {
                y = rand.Next(8);
            }
            while (y == x);
            do
            {
                z = rand.Next(8);
            }
            while (z==x || z==y);

            panelcetri.BackColor = colors[x];
            panelpieci.BackColor = colors[y];
            panelsesi.BackColor = colors[z];
        }
        private void buttemasizvele1_Click(object sender, EventArgs e)
        {
            this.Hide();
            Form3 tema = new Form3();
            tema.Show();
        }
    } 
}
