﻿namespace zimesanas_paligs
{
    partial class Form2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.panelsesi = new System.Windows.Forms.Panel();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.paneldivi = new System.Windows.Forms.Panel();
            this.paneltris = new System.Windows.Forms.Panel();
            this.panelviens = new System.Windows.Forms.Panel();
            this.panelcetri = new System.Windows.Forms.Panel();
            this.panelpieci = new System.Windows.Forms.Panel();
            this.butizvele1 = new System.Windows.Forms.Button();
            this.butizvele2 = new System.Windows.Forms.Button();
            this.butizvele3 = new System.Windows.Forms.Button();
            this.buttemasizvele1 = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // panelsesi
            // 
            this.panelsesi.BackColor = System.Drawing.SystemColors.Control;
            this.panelsesi.Location = new System.Drawing.Point(686, 193);
            this.panelsesi.Name = "panelsesi";
            this.panelsesi.Size = new System.Drawing.Size(65, 65);
            this.panelsesi.TabIndex = 3;
            // 
            // label1
            // 
            this.label1.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Courier New", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(186)));
            this.label1.Location = new System.Drawing.Point(282, 47);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(231, 34);
            this.label1.TabIndex = 6;
            this.label1.Text = "Krāsu izvēle";
            // 
            // label2
            // 
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(80, 111);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(139, 62);
            this.label2.TabIndex = 7;
            this.label2.Text = "1 Nejaušas krāsas izvēle";
            this.label2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label3
            // 
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(585, 111);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(139, 62);
            this.label3.TabIndex = 8;
            this.label3.Text = "3 Nejaušu krāsu izvēle";
            this.label3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label4
            // 
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(324, 111);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(139, 62);
            this.label4.TabIndex = 9;
            this.label4.Text = "2 Nejaušu krāsu izvēle";
            this.label4.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // paneldivi
            // 
            this.paneldivi.BackColor = System.Drawing.SystemColors.Control;
            this.paneldivi.Location = new System.Drawing.Point(327, 193);
            this.paneldivi.Name = "paneldivi";
            this.paneldivi.Size = new System.Drawing.Size(65, 65);
            this.paneldivi.TabIndex = 10;
            // 
            // paneltris
            // 
            this.paneltris.BackColor = System.Drawing.SystemColors.Control;
            this.paneltris.Location = new System.Drawing.Point(398, 193);
            this.paneltris.Name = "paneltris";
            this.paneltris.Size = new System.Drawing.Size(65, 65);
            this.paneltris.TabIndex = 11;
            // 
            // panelviens
            // 
            this.panelviens.BackColor = System.Drawing.SystemColors.Control;
            this.panelviens.Location = new System.Drawing.Point(118, 193);
            this.panelviens.Name = "panelviens";
            this.panelviens.Size = new System.Drawing.Size(65, 65);
            this.panelviens.TabIndex = 12;
            this.panelviens.Paint += new System.Windows.Forms.PaintEventHandler(this.panelviens_Paint);
            // 
            // panelcetri
            // 
            this.panelcetri.BackColor = System.Drawing.SystemColors.Control;
            this.panelcetri.Location = new System.Drawing.Point(544, 193);
            this.panelcetri.Name = "panelcetri";
            this.panelcetri.Size = new System.Drawing.Size(65, 65);
            this.panelcetri.TabIndex = 13;
            // 
            // panelpieci
            // 
            this.panelpieci.BackColor = System.Drawing.SystemColors.Control;
            this.panelpieci.Location = new System.Drawing.Point(615, 193);
            this.panelpieci.Name = "panelpieci";
            this.panelpieci.Size = new System.Drawing.Size(65, 65);
            this.panelpieci.TabIndex = 14;
            // 
            // butizvele1
            // 
            this.butizvele1.BackColor = System.Drawing.SystemColors.Control;
            this.butizvele1.Location = new System.Drawing.Point(98, 286);
            this.butizvele1.Name = "butizvele1";
            this.butizvele1.Size = new System.Drawing.Size(112, 31);
            this.butizvele1.TabIndex = 15;
            this.butizvele1.Text = "Izvēlēties";
            this.butizvele1.UseVisualStyleBackColor = false;
            this.butizvele1.Click += new System.EventHandler(this.butizvele1_Click_1);
            // 
            // butizvele2
            // 
            this.butizvele2.Location = new System.Drawing.Point(340, 286);
            this.butizvele2.Name = "butizvele2";
            this.butizvele2.Size = new System.Drawing.Size(112, 31);
            this.butizvele2.TabIndex = 16;
            this.butizvele2.Text = "Izvēlēties";
            this.butizvele2.UseVisualStyleBackColor = true;
            this.butizvele2.Click += new System.EventHandler(this.butizvele2_Click);
            // 
            // butizvele3
            // 
            this.butizvele3.Location = new System.Drawing.Point(597, 286);
            this.butizvele3.Name = "butizvele3";
            this.butizvele3.Size = new System.Drawing.Size(112, 31);
            this.butizvele3.TabIndex = 17;
            this.butizvele3.Text = "Izvēlēties";
            this.butizvele3.UseVisualStyleBackColor = true;
            this.butizvele3.Click += new System.EventHandler(this.butizvele3_Click);
            // 
            // buttemasizvele1
            // 
            this.buttemasizvele1.BackColor = System.Drawing.SystemColors.ControlDarkDark;
            this.buttemasizvele1.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(186)));
            this.buttemasizvele1.ForeColor = System.Drawing.SystemColors.Control;
            this.buttemasizvele1.Location = new System.Drawing.Point(572, 398);
            this.buttemasizvele1.Name = "buttemasizvele1";
            this.buttemasizvele1.Size = new System.Drawing.Size(203, 29);
            this.buttemasizvele1.TabIndex = 18;
            this.buttemasizvele1.Text = "Tēmas izvēle";
            this.buttemasizvele1.UseVisualStyleBackColor = false;
            this.buttemasizvele1.Click += new System.EventHandler(this.buttemasizvele1_Click);
            // 
            // Form2
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.AppWorkspace;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.buttemasizvele1);
            this.Controls.Add(this.butizvele3);
            this.Controls.Add(this.butizvele2);
            this.Controls.Add(this.butizvele1);
            this.Controls.Add(this.panelpieci);
            this.Controls.Add(this.panelcetri);
            this.Controls.Add(this.panelviens);
            this.Controls.Add(this.paneltris);
            this.Controls.Add(this.paneldivi);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.panelsesi);
            this.MaximizeBox = false;
            this.Name = "Form2";
            this.Text = "Zīmēšanas palīgs";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Panel panelsesi;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Panel paneldivi;
        private System.Windows.Forms.Panel paneltris;
        private System.Windows.Forms.Panel panelviens;
        private System.Windows.Forms.Panel panelcetri;
        private System.Windows.Forms.Panel panelpieci;
        private System.Windows.Forms.Button butizvele1;
        private System.Windows.Forms.Button butizvele2;
        private System.Windows.Forms.Button butizvele3;
        private System.Windows.Forms.Button buttemasizvele1;
    }
}