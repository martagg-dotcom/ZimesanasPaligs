﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace zimesanas_paligs
{
    public partial class Form3 : Form
    {
        public Form3()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }
        Random rand = new Random();
        private void butizveleo_Click(object sender, EventArgs e)
        {
            string[] obj = new string[11] { "Augs", "Dzīvnieks", "Puķe", "Ēdiens", "Dzēriens", "Cilvēks", "Priekšmets ", "Dabas parādība", "Rotaļlieta", "Apģērbs", "Figūras" };
            label5.Text = obj[rand.Next(11)];
            label5.Visible = true;
        }


        private void butizvelef_Click(object sender, EventArgs e)
        {
            string[] fons = new string[11] { "Okeāns", "Savanna", "Džungļi", "Upe", "Istaba", "Mežs", "Debesis", "Pļava", "Puķu lauks", "Zvaigznes", "Dārzs" };
            label6.Text = fons[rand.Next(11)];
            label6.Visible = true;
        }



        private void butizveles_Click(object sender, EventArgs e)
        {
            string[] stils = new string[11] { "Sirreālisms", "Reālisms", "Kubisms", "Postimpressionisms", "Fovisms", "Ekspresionisms", "Dadaisms", "Simbolisms", "Grafiskais", "Skice", "Baroks" };
            label7.Text = stils[rand.Next(11)];
            label7.Visible = true;
        }




        private void butkrasuizvele2_Click(object sender, EventArgs e)
        {
            this.Hide();
            Form2 krasa = new Form2();
            krasa.Show();
        }

       
    }
}
