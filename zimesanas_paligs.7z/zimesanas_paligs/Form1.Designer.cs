﻿namespace zimesanas_paligs
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.labzimesanaspaligs = new System.Windows.Forms.Label();
            this.butkrasuizvele1 = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // labzimesanaspaligs
            // 
            this.labzimesanaspaligs.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.labzimesanaspaligs.Font = new System.Drawing.Font("Courier New", 25.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(186)));
            this.labzimesanaspaligs.Location = new System.Drawing.Point(239, 132);
            this.labzimesanaspaligs.Name = "labzimesanaspaligs";
            this.labzimesanaspaligs.Size = new System.Drawing.Size(326, 121);
            this.labzimesanaspaligs.TabIndex = 0;
            this.labzimesanaspaligs.Text = "Zīmēšanas palīgs";
            this.labzimesanaspaligs.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // butkrasuizvele1
            // 
            this.butkrasuizvele1.BackColor = System.Drawing.SystemColors.ControlDarkDark;
            this.butkrasuizvele1.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(186)));
            this.butkrasuizvele1.ForeColor = System.Drawing.SystemColors.Control;
            this.butkrasuizvele1.Location = new System.Drawing.Point(550, 395);
            this.butkrasuizvele1.Name = "butkrasuizvele1";
            this.butkrasuizvele1.Size = new System.Drawing.Size(203, 29);
            this.butkrasuizvele1.TabIndex = 1;
            this.butkrasuizvele1.Text = "Krāsu izvēle";
            this.butkrasuizvele1.UseVisualStyleBackColor = false;
            this.butkrasuizvele1.Click += new System.EventHandler(this.butkrasuizvele1_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.AppWorkspace;
            this.ClientSize = new System.Drawing.Size(782, 453);
            this.Controls.Add(this.butkrasuizvele1);
            this.Controls.Add(this.labzimesanaspaligs);
            this.MaximizeBox = false;
            this.Name = "Form1";
            this.Text = "Zīmēšanas palīgs";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Label labzimesanaspaligs;
        private System.Windows.Forms.Button butkrasuizvele1;
    }
}

